from .script import main
main()